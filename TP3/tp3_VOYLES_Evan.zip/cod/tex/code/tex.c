// examples of code snippets used to build the latex.

#include "tree.h"
#include "list.h"

int main() {


    // Instantiation
    BinTree *root = newBinTree(10);

    // insertion
    addKeyBST(root, 1);
    addKeyBST(root, 0);
    addKeyBST(root, 13);
    addKeyBST(root, 5);
    addKeyBST(root, 8);
    addKeyBST(root, 25);
    addKeyBST(root, 3);

    removeKey(root, 3);



}